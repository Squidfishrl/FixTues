#!/usr/bin/env python
from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

mydb = mysql.connector.connect(
    host="localhost",
    user="yassen_test_user",
    passwd="lordbiznes2004",
    database="yassen_test"
)


#       ----------
#       | ROUTES |
#       ----------

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/events', methods=['GET'])
def events():
    sql = 'SELECT * FROM events'
    mycursor = mydb.cursor(dictionary=True, buffered=True)
    mycursor.execute(sql)

    return render_template('events.html', rows=mycursor)


@app.route('/new_event')
def new_event():
    return render_template('new_event.html')


@app.route('/edit_event')
def new_event():
    return render_template('edit_event.html')


@app.route('/register')
def register():
    return render_template('register.html')


@app.route('/login')
def login():
    return render_template('login.html')


#
#       SPECIAL
#

@app.route('/submit', methods=['POST'])
def submit():
    sql = "INSERT INTO events (title, status) VALUES (%s, %s)"
    val = (request.form['title'], request.form['status'])

    mycursor = mydb.cursor(buffered=True)
    mycursor.execute(sql, val)

    mydb.commit()

    print(mycursor.rowcount, 'record inserted.')

    return redirect(url_for('events'))


@app.route('/edit', method=['POST'])
def edit():
    sql = "UPDATE events SET title=%s, status=%s"
    val = (request.form['title'], request.form['status'])


if __name__ == '__main__':
    app.run(debug=True, host='192.168.2.107', port=5000)
